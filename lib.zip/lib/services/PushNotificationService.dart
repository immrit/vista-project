import '../security/logging_utility.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../provider/notification_provider.dart';
import '../main.dart';
import 'ChatService.dart';
import 'notification_navigation_service.dart';

/// Provider برای دسترسی به PushNotificationService
final pushNotificationServiceProvider = Provider<PushNotificationService>(
  (ref) => PushNotificationService(ref),
);

class PushNotificationService {
  final Ref ref;
  PushNotificationService(this.ref);

  final _firebaseMessaging = FirebaseMessaging.instance;
  final _supabase = Supabase.instance.client;
  final _flutterLocalNotifications = FlutterLocalNotificationsPlugin();

  /// این متغیر لیست اعلان‌های دریافتی رو نگه میداره
  final List<RemoteMessage> _notifications = [];
  List<RemoteMessage> get notifications => _notifications;

  /// مقداردهی اولیه سرویس
  Future<void> init(BuildContext context) async {
    try {
      // بررسی اینکه Firebase initialize شده یا نه
      if (Firebase.apps.isEmpty) {
        print(
          '⚠️ Firebase not initialized, skipping PushNotificationService init',
        );
        return;
      }

      // درخواست اجازه دسترسی به نوتیفیکیشن (iOS / Android 13+)
      await _firebaseMessaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );

      // مقداردهی flutter_local_notifications
      const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
      const iOSInit = DarwinInitializationSettings();
      const initSettings = InitializationSettings(
        android: androidInit,
        iOS: iOSInit,
      );

      await _flutterLocalNotifications.initialize(
        initSettings,
        onDidReceiveNotificationResponse: (details) {
          if (details.payload != null) {
            try {
              final data = jsonDecode(details.payload!) as Map<String, dynamic>;

              // هندل پاسخ سریع
              if (details.actionId == 'reply' && details.input != null) {
                final conversationId = data['conversation_id'];
                if (conversationId != null &&
                    conversationId.toString().isNotEmpty) {
                  handleQuickReply(conversationId.toString(), details.input!);
                }
              } else {
                // هندل ناوبری عادی
                handleNotificationNavigation(context, data);
              }
            } catch (e) {
              logInfo('❌ خطا در پردازش payload نوتیفیکیشن: $e');
            }
          }
        },
      );

      // گرفتن و ذخیره توکن FCM در سوپابیس
      await _saveFcmToken();

      // گوش دادن به پیام‌ها در فورگراند
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        logInfo('📱 پیام FCM در فورگراند دریافت شد: ${message.data['type']}');
        _notifications.add(message);
        _showNotification(message);

        // اضافه کردن اعلان به notificationsProvider
        _addNotificationToProvider(message);
      });

      // ✅ Handler برای زمانی که روی اعلان کلیک میشه (app در background)
      FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        logInfo('📬 FCM notification opened (background)');
        logInfo('   Data: ${message.data}');

        final context = navigatorKey.currentContext;
        if (context != null) {
          NotificationNavigationService.handleFCMPayload(
            context: context,
            data: message.data,
          );
        }
      });

      // ✅ اگر اپ از حالت بسته با نوتیف باز شد - این در main.dart handle میشه
      // final initialMessage = await _firebaseMessaging.getInitialMessage();
      // if (initialMessage != null) {
      //   NotificationNavigationService.handleFCMPayload(
      //     context: context,
      //     data: initialMessage.data,
      //   );
      // }
    } catch (e) {
      logInfo('❌ خطا در راه‌اندازی PushNotificationService: $e');
    }
  }

  /// ذخیره توکن FCM در جدول profiles
  Future<void> _saveFcmToken() async {
    try {
      // بررسی اینکه Firebase initialize شده یا نه
      if (Firebase.apps.isEmpty) {
        logInfo('⚠️ Firebase not initialized, skipping FCM token save');
        return;
      }

      final token = await _firebaseMessaging.getToken();
      if (token == null) {
        logInfo('⚠️ FCM Token دریافت نشد');
        return;
      }

      final user = _supabase.auth.currentUser;
      if (user == null) {
        logInfo('⚠️ کاربر لاگین نشده، FCM Token ذخیره نشد');
        return;
      }

      final username = user.userMetadata?['username'] ??
          user.email?.split('@')[0] ??
          'user_${user.id}';

      final fullName = user.userMetadata?['full_name'] ?? username;

      // استفاده از upsert به جای update برای اطمینان از ذخیره شدن
      await _supabase.from("profiles").upsert({
        'id': user.id,
        'fcm_token': token,
        'username': username,
        'full_name': fullName,
      });
      
      logInfo('✅ FCM Token با موفقیت در سوپابیس ذخیره شد برای کاربر: ${user.id}');
    } catch (e) {
      logInfo('❌ خطا در ذخیره FCM Token: $e');
      logInfo('Stack trace: ${StackTrace.current}');
    }
  }

  /// نمایش نوتیفیکیشن لوکال در فورگراند
  Future<void> _showNotification(RemoteMessage message) async {
    final notification = message.notification;
    final data = message.data;

    // تعیین نوع کانال بر اساس نوع اعلان
    String channelId = 'default_channel_id';
    String channelName = 'عمومی';
    String channelDescription = 'اعلان‌های عمومی';
    List<AndroidNotificationAction>? actions;

    final type = data['type'];
    if (type == 'chat_message') {
      channelId = 'chat_messages';
      channelName = 'پیام‌های چت';
      channelDescription = 'اعلان پیام‌های جدید چت';

      // اضافه کردن دکمه پاسخ سریع برای چت
      actions = [
        AndroidNotificationAction(
          'reply',
          'پاسخ',
          inputs: [AndroidNotificationActionInput()],
          showsUserInterface: true,
        ),
      ];
    } else if (type == 'like' ||
        type == 'new_comment' ||
        type == 'comment_reply' ||
        type == 'follow' ||
        type == 'follow_request' ||
        type == 'follow_request_accepted') {
      channelId = 'social_notify';
      channelName = 'اعلان اجتماعی';
      channelDescription = 'اعلان‌های اجتماعی (لایک، کامنت، دنبال‌کننده و ...)';
    }

    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      actions: actions,
    );

    const iOSDetails = DarwinNotificationDetails();

    final platformDetails = NotificationDetails(
      android: androidDetails,
      iOS: iOSDetails,
    );

    // استفاده از محتوای FCM data یا notification body
    final title = data['title'] ?? notification?.title ?? 'اعلان جدید';
    String body =
        data['message'] ?? data['content'] ?? notification?.body ?? '';

    // فیلتر کردن لینک‌ها از محتوای نوتیفیکیشن
    body = _filterLinksFromText(body);

    await _flutterLocalNotifications.show(
      message.hashCode,
      title,
      _shorten(body),
      platformDetails,
      payload: jsonEncode(message.data),
    );
  }

  /// فیلتر کردن لینک‌ها از متن
  String _filterLinksFromText(String text) {
    if (text.isEmpty) return text;

    // فیلتر کردن لینک‌های Vista و پست‌های اشتراکی
    String filteredText = text;

    // حذف لینک‌های Vista
    filteredText =
        filteredText.replaceAll(RegExp(r'https?://[^\s]*vista[^\s]*'), '');
    filteredText =
        filteredText.replaceAll(RegExp(r'https?://[^\s]*post/[^\s]*'), '');
    filteredText =
        filteredText.replaceAll(RegExp(r'https?://[^\s]*coffevista[^\s]*'), '');
    filteredText =
        filteredText.replaceAll(RegExp(r'https?://[^\s]*arvan[^\s]*'), '');

    // حذف لینک‌های عمومی
    filteredText = filteredText.replaceAll(RegExp(r'https?://[^\s]*'), '');

    // حذف metadata های پست‌های اشتراکی
    filteredText = filteredText.replaceAll(RegExp(r'🖼️ آواتار:.*'), '');
    filteredText = filteredText.replaceAll(RegExp(r'🎥 ویدیو:.*'), '');
    filteredText = filteredText.replaceAll(RegExp(r'🏷️ تگ‌ها:.*'), '');
    filteredText = filteredText.replaceAll(RegExp(r'🔗.*'), '');
    filteredText = filteredText.replaceAll(RegExp(r'📝 پست از.*'), '');

    return filteredText.trim();
  }

  /// کوتاه کردن متن طولانی
  String _shorten(String text, [int maxLength = 80]) {
    if (text.length <= maxLength) return text;
    return "${text.substring(0, maxLength)}...";
  }

  /// هدایت کاربر به صفحات مرتبط بر اساس دیتای ارسالی سرور
  /// این متد برای backward compatibility نگه داشته شده
  /// اما بهتر است از NotificationNavigationService استفاده شود
  @Deprecated('Use NotificationNavigationService.handleFCMPayload instead')
  void handleNotificationNavigation(
    BuildContext context,
    Map<String, dynamic> data,
  ) {
    // استفاده از سرویس جدید
    NotificationNavigationService.handleFCMPayload(
      context: context,
      data: data,
    );
  }

  /// هندل پاسخ سریع به اعلان چت
  Future<void> handleQuickReply(String conversationId, String replyText) async {
    try {
      // ارسال پیام به سرور
      // اینجا باید ChatService یا سرویس مربوطه را فراخوانی کنید
      logInfo('📱 پاسخ سریع ارسال شد: $replyText به چت $conversationId');

      // ارسال پیام به سرور
      try {
        final chatService = ChatService();
        await chatService.sendMessage(
          conversationId: conversationId,
          content: replyText,
        );
        logInfo('✅ پیام پاسخ سریع با موفقیت ارسال شد');
      } catch (e) {
        logInfo('❌ خطا در ارسال پیام به سرور: $e');
        // در صورت خطا، پیام را به صورت محلی ذخیره کنید
        // یا به کاربر اطلاع دهید که پیام ارسال نشده
      }
    } catch (e) {
      logInfo('❌ خطا در ارسال پاسخ سریع: $e');
    }
  }

  /// اضافه کردن اعلان به notificationsProvider
  void _addNotificationToProvider(RemoteMessage message) {
    try {
      // استفاده از ref.read برای دسترسی به notificationsProvider
      final notifier = ref.read(notificationsProvider.notifier);
      notifier.addNotificationFromPush(message);
      logInfo('✅ اعلان با موفقیت به provider اضافه شد: ${message.data['type']}');
    } catch (e) {
      logInfo('❌ خطا در اضافه کردن اعلان به provider: $e');
      logInfo('Stack trace: ${StackTrace.current}');
    }
  }
}
