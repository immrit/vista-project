import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;

import 'package:Vista/model/session_model.dart';
import 'package:Vista/provider/session_provider.dart';
import 'package:Vista/services/session_manager_service.dart';

class ActiveSessionsScreen extends ConsumerStatefulWidget {
  const ActiveSessionsScreen({super.key});

  @override
  ConsumerState<ActiveSessionsScreen> createState() =>
      _ActiveSessionsScreenState();
}

class _ActiveSessionsScreenState extends ConsumerState<ActiveSessionsScreen> {
  bool _canTerminate = false;
  int _remainingDays = 0;
  bool _isLoadingPermission = true;

  @override
  void initState() {
    super.initState();
    // تنظیم زبان فارسی برای timeago
    timeago.setLocaleMessages('fa', timeago.FaMessages());
    _checkTerminatePermission();
  }

  Future<void> _checkTerminatePermission() async {
    setState(() {
      _isLoadingPermission = true;
    });

    final sessionManager = ref.read(sessionManagerProvider);
    final canTerminate = await sessionManager.canTerminateOtherSessions();
    final remainingDays = await sessionManager.getRemainingDaysToTerminate();

    if (mounted) {
      setState(() {
        _canTerminate = canTerminate;
        _remainingDays = remainingDays;
        _isLoadingPermission = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final sessionsAsync = ref.watch(activeSessionsProvider);
    final sessionManager = ref.watch(sessionManagerProvider);
    final currentSessionId = sessionManager.currentSessionId;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.grey[100],
        appBar: AppBar(
          title: const Text(
            'نشست‌های فعال',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          elevation: 0,
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              tooltip: 'به‌روزرسانی',
              onPressed: () async {
                ref.invalidate(activeSessionsProvider);
                await _checkTerminatePermission();
              },
            ),
            IconButton(
              icon: const Icon(Icons.info_outline),
              tooltip: 'راهنما',
              onPressed: () => _showInfoDialog(context),
            ),
          ],
        ),
        body: sessionsAsync.when(
          data: (sessions) {
            if (sessions.isEmpty) {
              return _buildEmptyState(isDark);
            }
            return Column(
              children: [
                _buildHeader(sessions.length, isDark),
                if (!_isLoadingPermission) _buildTerminationStatusCard(isDark),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: sessions.length,
                    itemBuilder: (context, index) {
                      final session = sessions[index];
                      final isCurrentSession = session.id == currentSessionId;
                      return _buildSessionCard(
                        context,
                        session,
                        isCurrentSession,
                        sessionManager,
                        isDark,
                      );
                    },
                  ),
                ),
                _buildTerminateAllButton(
                    sessionManager, sessions.length > 1, isDark),
              ],
            );
          },
          loading: () => const Center(
            child: CircularProgressIndicator(),
          ),
          error: (error, stack) => _buildErrorState(error.toString(), isDark),
        ),
      ),
    );
  }

  Widget _buildTerminationStatusCard(bool isDark) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _canTerminate
            ? Colors.green.shade50
            : Colors.orange.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _canTerminate
              ? Colors.green.shade200
              : Colors.orange.shade200,
          width: 1.5,
        ),
      ),
      child: Row(
        children: [
          Icon(
            _canTerminate ? Icons.check_circle : Icons.schedule,
            color: _canTerminate
                ? Colors.green.shade700
                : Colors.orange.shade700,
            size: 32,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _canTerminate
                      ? 'می‌توانید نشست‌های دیگر را حذف کنید'
                      : 'محدودیت امنیتی',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: _canTerminate
                        ? Colors.green.shade900
                        : Colors.orange.shade900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _canTerminate
                      ? 'نشست فعلی شما بیش از 10 روز قدمت دارد و می‌توانید نشست‌های دیگر را مدیریت کنید.'
                      : 'برای امنیت حساب، باید $_remainingDays روز دیگر صبر کنید تا بتوانید نشست‌های دیگر را حذف کنید.',
                  style: TextStyle(
                    fontSize: 13,
                    color: _canTerminate
                        ? Colors.green.shade800
                        : Colors.orange.shade800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(int count, bool isDark) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade400, Colors.blue.shade600],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.devices,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'دستگاه‌های متصل',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$count دستگاه فعال',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSessionCard(
    BuildContext context,
    SessionModel session,
    bool isCurrentSession,
    SessionManagerService sessionManager,
    bool isDark,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF252525) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: isCurrentSession
            ? Border.all(color: Colors.green, width: 2)
            : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: _buildDeviceIcon(session.deviceInfo),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              session.deviceInfo.deviceName,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              session.deviceInfo.deviceModel,
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'نسخه ${session.appVersion ?? 'نامشخص'}',
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 12,
              ),
            ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.access_time,
                  size: 14,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Text(
                  'آخرین فعالیت: ${_formatLastActivity(session.lastActivity)}',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            if (session.ipAddress != null)
              Row(
                children: [
                  Icon(
                    Icons.location_on_outlined,
                    size: 14,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'IP: ${session.ipAddress}',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            if (isCurrentSession) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.green.shade200),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.check_circle,
                      size: 16,
                      color: Colors.green.shade700,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'دستگاه فعلی',
                      style: TextStyle(
                        color: Colors.green.shade700,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
        trailing: !isCurrentSession
            ? IconButton(
                icon: Icon(
                  Icons.logout,
                  color: _canTerminate
                      ? Colors.red.shade400
                      : Colors.grey.shade400,
                ),
                tooltip: _canTerminate
                    ? 'خاتمه نشست'
                    : 'امکان حذف پس از $_remainingDays روز',
                onPressed: _canTerminate
                    ? () => _showTerminateDialog(
                          context,
                          session,
                          sessionManager,
                          isDark,
                        )
                    : null,
              )
            : null,
      ),
    );
  }

  Widget _buildDeviceIcon(SessionDeviceInfo deviceInfo) {
    IconData iconData;
    Color iconColor;

    switch (deviceInfo.targetPlatform) {
      case TargetPlatform.android:
        iconData = Icons.android;
        iconColor = Colors.green;
        break;
      case TargetPlatform.iOS:
        iconData = Icons.apple;
        iconColor = Colors.grey[800]!;
        break;
      case TargetPlatform.windows:
        iconData = Icons.desktop_windows;
        iconColor = Colors.blue;
        break;
      case TargetPlatform.macOS:
        iconData = Icons.laptop_mac;
        iconColor = Colors.grey[600]!;
        break;
      case TargetPlatform.linux:
        iconData = Icons.computer;
        iconColor = Colors.orange;
        break;
      default:
        iconData = Icons.devices;
        iconColor = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: iconColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        iconData,
        color: iconColor,
        size: 32,
      ),
    );
  }

  Widget _buildTerminateAllButton(
    SessionManagerService sessionManager,
    bool hasOtherSessions,
    bool isDark,
  ) {
    if (!hasOtherSessions) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF252525) : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _canTerminate
                ? () => _showTerminateAllDialog(context, sessionManager, isDark)
                : null,
            icon: Icon(_canTerminate ? Icons.logout : Icons.schedule),
            label: Text(
              _canTerminate
                  ? 'خروج از همه دستگاه‌ها'
                  : 'امکان حذف پس از $_remainingDays روز',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _canTerminate
                  ? Colors.red.shade400
                  : Colors.grey.shade400,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 0,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(bool isDark) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.devices_other,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'هیچ نشست فعالی وجود ندارد',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'پس از ورود به حساب، نشست‌های فعال اینجا نمایش داده می‌شوند',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(String error, bool isDark) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: 80,
            color: Colors.red[300],
          ),
          const SizedBox(height: 16),
          Text(
            'خطا در بارگذاری نشست‌ها',
            style: TextStyle(
              fontSize: 18,
              color: Colors.red[700],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              error,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => ref.refresh(activeSessionsProvider),
            icon: const Icon(Icons.refresh),
            label: const Text('تلاش مجدد'),
          ),
        ],
      ),
    );
  }

  String _formatLastActivity(DateTime lastActivity) {
    return timeago.format(
      lastActivity,
      locale: 'fa',
      allowFromNow: true,
    );
  }

  Future<void> _showTerminateDialog(
    BuildContext context,
    SessionModel session,
    SessionManagerService sessionManager,
    bool isDark,
  ) async {
    if (!_canTerminate) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'برای حذف نشست‌های دیگر، باید $_remainingDays روز دیگر صبر کنید.',
          ),
          backgroundColor: Colors.orange,
          duration: const Duration(seconds: 4),
        ),
      );
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF252525) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange[700]),
            const SizedBox(width: 12),
            const Text('تایید خاتمه نشست'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('آیا مطمئن هستید که می‌خواهید این نشست را خاتمه دهید؟'),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    session.deviceInfo.deviceName,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    session.deviceInfo.deviceModel,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'دستگاه مربوطه از حساب کاربری شما خارج خواهد شد.',
              style: TextStyle(
                color: Colors.red[700],
                fontSize: 12,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('انصراف'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('خاتمه نشست'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      _showLoadingDialog(context, isDark);

      final result = await sessionManager.terminateSession(session.id);

      if (context.mounted) {
        Navigator.pop(context); // بستن loading dialog

        if (result.success) {
          // به‌روزرسانی لیست نشست‌ها
          ref.invalidate(activeSessionsProvider);
          await _checkTerminatePermission();
          
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.white),
                  SizedBox(width: 12),
                  Text('نشست با موفقیت خاتمه یافت'),
                ],
              ),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Icon(
                    result.remainingDays != null
                        ? Icons.schedule
                        : Icons.error,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      result.errorMessage ?? 'خطا در خاتمه نشست',
                    ),
                  ),
                ],
              ),
              backgroundColor: result.remainingDays != null
                  ? Colors.orange
                  : Colors.red,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              duration: Duration(
                seconds: result.remainingDays != null ? 5 : 3,
              ),
            ),
          );
        }
      }
    }
  }

  Future<void> _showTerminateAllDialog(
    BuildContext context,
    SessionManagerService sessionManager,
    bool isDark,
  ) async {
    if (!_canTerminate) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'برای حذف نشست‌های دیگر، باید $_remainingDays روز دیگر صبر کنید.',
          ),
          backgroundColor: Colors.orange,
          duration: const Duration(seconds: 4),
        ),
      );
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF252525) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red[700]),
            const SizedBox(width: 12),
            const Text('تایید خروج از همه دستگاه‌ها'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'آیا مطمئن هستید که می‌خواهید از همه دستگاه‌ها به جز دستگاه فعلی خارج شوید؟',
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red[200]!),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.red[700], size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'تمام دستگاه‌های دیگر از حساب کاربری شما خارج خواهند شد.',
                      style: TextStyle(
                        color: Colors.red[700],
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('انصراف'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('خروج از همه'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      _showLoadingDialog(context, isDark);

      final result = await sessionManager.terminateOtherSessions();

      if (context.mounted) {
        Navigator.pop(context); // بستن loading dialog

        if (result.success) {
          // به‌روزرسانی لیست نشست‌ها
          ref.invalidate(activeSessionsProvider);
          await _checkTerminatePermission();
          
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.white),
                  SizedBox(width: 12),
                  Text('خروج از همه دستگاه‌ها با موفقیت انجام شد'),
                ],
              ),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Icon(
                    result.remainingDays != null
                        ? Icons.schedule
                        : Icons.error,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      result.errorMessage ?? 'خطا در خروج از دستگاه‌ها',
                    ),
                  ),
                ],
              ),
              backgroundColor: result.remainingDays != null
                  ? Colors.orange
                  : Colors.red,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              duration: Duration(
                seconds: result.remainingDays != null ? 5 : 3,
              ),
            ),
          );
        }
      }
    }
  }

  void _showLoadingDialog(BuildContext context, bool isDark) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: Card(
          color: isDark ? const Color(0xFF252525) : Colors.white,
          child: const Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('در حال پردازش...'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showInfoDialog(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF252525) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Icon(Icons.info, color: Colors.blue[700]),
            const SizedBox(width: 12),
            const Text('درباره نشست‌های فعال'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInfoItem(
              Icons.devices,
              'نمایش دستگاه‌ها',
              'تمام دستگاه‌هایی که به حساب شما متصل هستند را مشاهده کنید.',
            ),
            const SizedBox(height: 12),
            _buildInfoItem(
              Icons.security,
              'امنیت',
              'در صورت مشاهده دستگاه ناشناس، می‌توانید آن را خاتمه دهید.',
            ),
            const SizedBox(height: 12),
            _buildInfoItem(
              Icons.logout,
              'خروج سریع',
              'امکان خروج از همه دستگاه‌ها با یک کلیک.',
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('متوجه شدم'),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String title, String description) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.blue[700], size: 24),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                description,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

