import '../../security/logging_utility.dart';
import 'package:Vista/view/screen/chat/ChatConversationsScreen.dart'
    show ChatConversationsScreen;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:badges/badges.dart' as badges;
import '../../provider/profile_completion_provider.dart';
import '/main.dart';
import 'PublicPosts/AddPost.dart';
import 'PublicPosts/profileScreen.dart';
import 'PublicPosts/publicPosts.dart';
import 'searchPage.dart';
import '../../provider/chat_provider.dart';
import '../util/responsive_constants.dart';

// استریم تعداد *مکالمه‌های* خوانده‌نشده
final unreadConversationsCountProvider = StreamProvider<int>((ref) {
  final userId = supabase.auth.currentUser?.id;
  if (userId == null) return const Stream.empty();

  // به استریم مکالمات گوش می‌دهیم
  // تغییر به cachedConversationsStreamProvider برای واکنش سریع‌تر به تغییرات کش
  return ref.watch(cachedConversationsStreamProvider).when(
        data: (conversations) {
          // مکالماتی را که پیام خوانده‌نشده دارند، فیلتر و شمارش می‌کنیم
          final count = conversations.where((c) => (c.unreadCount) > 0).length;
          return Stream.value(count);
        },
        loading: () => Stream.value(0), // در حال بارگذاری، تعداد صفر است
        error: (error, stackTrace) {
          logInfo('Error in unreadConversationsCountProvider: $error');
          return Stream.value(0); // در صورت خطا، تعداد صفر است
        },
      );
});

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _selectedIndex = 0;
  DateTime? _lastPressed;

  // لیست صفحات با استفاده از late برای اینیشیالایز تنها یکبار
  late final List<Widget> _tabs;

  @override
  void initState() {
    super.initState();
    _checkProfileCompletion();
    // ساخت یکبار صفحات در initState
    final currentUser = supabase.auth.currentUser;
    final userId = currentUser?.id ?? '';
    final username = currentUser?.userMetadata?['username'] ??
        currentUser?.userMetadata?['full_name'] ??
        'کاربر';

    _tabs = [
      const PublicPostsScreen(), // صفحه پست‌های عمومی
      const SearchPage(), // صفحه جستجو
      const AddPublicPostScreen(), // صفحه افزودن پست
      const ChatConversationsScreen(), // صفحه چت
      ProfileScreen(
        userId: userId,
        username: username,
      ), // صفحه پروفایل
    ];
  }

  void _checkProfileCompletion() {
    // اجرای غیرمسدودکننده در پس‌زمینه
    Future.microtask(() async {
      try {
        final isComplete = await ref
            .read(profileCompletionProvider.notifier)
            .checkProfileCompletion()
            .timeout(const Duration(seconds: 2), onTimeout: () => true);
        if (!isComplete && mounted) {
          // انتقال به صفحه ویرایش پروفایل با تأخیر کوتاه
          await Future.delayed(const Duration(milliseconds: 500));
          if (mounted) {
            Navigator.pushNamed(context, '/editeProfile');
          }
        }
      } catch (e) {
        // خطا را نادیده می‌گیریم - کاربر نباید متوجه شود
      }
    });
  }

  // هندل کردن تغییر تب
  void _onItemTapped(int index) {
    if (index == 2) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => const AddPublicPostScreen()),
      );
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  Future<bool> _onWillPop() async {
    if (_selectedIndex != 0) {
      setState(() {
        _selectedIndex = 0;
      });
      return false;
    } else {
      final now = DateTime.now();
      if (_lastPressed == null ||
          now.difference(_lastPressed!) > const Duration(seconds: 2)) {
        _lastPressed = now;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('برای خروج دوباره دکمه بازگشت را بزنید'),
          ),
        );
        return false;
      }
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    // فعال کردن Provider سراسری نوتیفیکیشن چت (در پس‌زمینه)
    ref.watch(globalChatNotificationProvider);

    // استریم تعداد *مکالمه‌های* خوانده‌نشده
    final unreadConversationsCountAsync = ref.watch(
      unreadConversationsCountProvider,
    );

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        // استفاده از IndexedStack برای حفظ وضعیت صفحات
        body: IndexedStack(index: _selectedIndex, children: _tabs),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _selectedIndex,
          onDestinationSelected: _onItemTapped,
          destinations: <NavigationDestination>[
            NavigationDestination(
              icon: Image.asset(
                'lib/view/util/images/bottomnavigation/home-outline.png',
                width: 24,
                height: 24,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
              selectedIcon: Image.asset(
                'lib/view/util/images/bottomnavigation/home.png',
                width: 24,
                height: 24,
                color: Theme.of(context).primaryColor,
              ),
              label: '',
            ),
            NavigationDestination(
              icon: Image.asset(
                'lib/view/util/images/bottomnavigation/magnifying-glass.png',
                width: 24,
                height: 24,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
              selectedIcon: Image.asset(
                'lib/view/util/images/bottomnavigation/magnifying-glass.png',
                width: 24,
                height: 24,
                color: Theme.of(context).primaryColor,
              ),
              label: '',
            ),
            NavigationDestination(
              icon: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(
                  Icons.add,
                  size: 26,
                  color: Theme.of(context).primaryColor,
                ),
              ),
              selectedIcon: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Theme.of(context).primaryColor,
                      Theme.of(context).primaryColor.withValues(alpha: 0.8),
                    ],
                  ),
                ),
                child: const Icon(Icons.add, size: 26, color: Colors.white),
              ),
              label: '',
            ),
            // تب چت با بج نمایش پیام‌های جدید
            NavigationDestination(
              icon: _buildMessageBadge(
                'lib/view/util/images/bottomnavigation/email-outline.png',
                false,
                unreadConversationsCountAsync,
              ),
              selectedIcon: _buildMessageBadge(
                'lib/view/util/images/bottomnavigation/email.png',
                true,
                unreadConversationsCountAsync,
              ),
              label: '',
            ),
            NavigationDestination(
              icon: Image.asset(
                'lib/view/util/images/bottomnavigation/user-outline.png',
                width: 24,
                height: 24,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
              selectedIcon: Image.asset(
                'lib/view/util/images/bottomnavigation/user.png',
                width: 24,
                height: 24,
                color: Theme.of(context).primaryColor,
              ),
              label: '',
            ),
          ],
          elevation: 3,
          animationDuration: const Duration(milliseconds: 500),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        ),
      ),
    );
  }

  // تابع برای نمایش بج تعداد مکالمه‌های خوانده‌نشده
  Widget _buildMessageBadge(
    String iconPath,
    bool isSelected,
    AsyncValue<int> unreadConversationsCountAsync,
  ) {
    return unreadConversationsCountAsync.when(
      data: (count) {
        return badges.Badge(
          showBadge: count > 0,
          badgeContent: Text(
            count > 9 ? '۹+' : count.toString(),
            style: AppTextStyles.labelTiny.copyWith(color: Colors.white),
          ),
          badgeStyle: badges.BadgeStyle(
            badgeColor: Colors.red,
            padding: EdgeInsets.all(count > 9 ? 4 : 5), // پدینگ بج
          ),
          position: badges.BadgePosition.topEnd(top: -12, end: -12),
          child: Image.asset(
            iconPath,
            width: 24,
            height: 24,
            color: isSelected
                ? Theme.of(context).primaryColor
                : Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
        );
      },
      loading: () => Image.asset(
        iconPath,
        width: 24,
        height: 24,
        color: isSelected
            ? (Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black)
            : Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
      ), // نمایش آیکون بدون بج در حال لود
      error: (err, stack) => Image.asset(
        iconPath,
        width: 24,
        height: 24,
        color: isSelected
            ? (Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black)
            : Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
      ), // نمایش آیکون بدون بج در صورت خطا
    );
  }
}
