// lib/utils/date_time_extensions.dart
//
// Extension های تاریخ و زمان برای نمایش فارسی
//

import 'package:shamsi_date/shamsi_date.dart';

extension PersianDigitExtension on String {
  /// تبدیل اعداد انگلیسی به فارسی
  String toPersianDigit() {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    String result = this;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], persian[i]);
    }
    return result;
  }
}

extension DateTimeExtensions on DateTime {
  /// تبدیل به تاریخ شمسی
  Jalali toJalali() => Jalali.fromDateTime(this);

  // ═══════════════════════════════════════════════════════════════
  // 📅 FLOATING DATE - برای هدر شناور
  // ═══════════════════════════════════════════════════════════════

  /// نمایش تاریخ شناور (برای FloatingDateHeader)
  /// مثال: "امروز"، "دیروز"، "۵ آذر"، "۲۳ آبان ۱۴۰۳"
  String toFloatingDateLabel() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final messageDate = DateTime(year, month, day);
    
    final difference = today.difference(messageDate).inDays;

    // امروز
    if (difference == 0) {
      return 'امروز';
    }
    
    // دیروز
    if (difference == 1) {
      return 'دیروز';
    }
    
    // هفته جاری - نمایش روز هفته
    if (difference > 1 && difference < 7) {
      return _getPersianWeekDay();
    }
    
    final jalali = toJalali();
    
    // سال جاری - فقط روز و ماه
    if (jalali.year == Jalali.now().year) {
      return '${jalali.day} ${_getMonthName(jalali.month)}'.toPersianDigit();
    }
    
    // سال قبل - با سال
    return '${jalali.day} ${_getMonthName(jalali.month)} ${jalali.year}'
        .toPersianDigit();
  }

  // ═══════════════════════════════════════════════════════════════
  // ⏰ FIXED TIME - برای کنار پیام
  // ═══════════════════════════════════════════════════════════════

  /// نمایش زمان ثابت کنار پیام
  /// مثال: "۱۴:۳۰"
  String toFixedTimeLabel() {
    final h = hour.toString().padLeft(2, '0');
    final m = minute.toString().padLeft(2, '0');
    return '$h:$m'.toPersianDigit();
  }

  /// نمایش تاریخ و زمان کامل برای پیام
  /// مثال: "امروز ۱۴:۳۰" یا "دیروز ۰۹:۱۵" یا "۲۳ آبان ۱۴:۳۰"
  String toFullDateTimeLabel() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final messageDate = DateTime(year, month, day);
    
    final difference = today.difference(messageDate).inDays;
    final timeLabel = toFixedTimeLabel();

    // امروز
    if (difference == 0) {
      return 'امروز $timeLabel';
    }
    
    // دیروز
    if (difference == 1) {
      return 'دیروز $timeLabel';
    }
    
    // هفته جاری
    if (difference > 1 && difference < 7) {
      return '${_getPersianWeekDay()} $timeLabel';
    }
    
    final jalali = toJalali();
    
    // سال جاری
    if (jalali.year == Jalali.now().year) {
      return '${jalali.day} ${_getMonthName(jalali.month)} $timeLabel'
          .toPersianDigit();
    }
    
    // سال قبل
    return '${jalali.day} ${_getMonthName(jalali.month)} ${jalali.year} $timeLabel'
        .toPersianDigit();
  }

  // ═══════════════════════════════════════════════════════════════
  // 📊 DATE DIVIDER - برای تقسیم‌بندی پیام‌ها
  // ═══════════════════════════════════════════════════════════════

  /// نمایش تاریخ برای Date Divider
  /// مثال: "امروز"، "دیروز"، "پنج‌شنبه، ۵ آذر"، "۲۳ آبان ۱۴۰۳"
  String toDateDividerLabel() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final messageDate = DateTime(year, month, day);
    
    final difference = today.difference(messageDate).inDays;

    // امروز
    if (difference == 0) {
      return 'امروز';
    }
    
    // دیروز
    if (difference == 1) {
      return 'دیروز';
    }
    
    // هفته جاری - روز هفته + تاریخ
    if (difference > 1 && difference < 7) {
      final jalali = toJalali();
      return '${_getPersianWeekDay()}، ${jalali.day} ${_getMonthName(jalali.month)}'
          .toPersianDigit();
    }
    
    final jalali = toJalali();
    
    // سال جاری
    if (jalali.year == Jalali.now().year) {
      return '${_getPersianWeekDay()}، ${jalali.day} ${_getMonthName(jalali.month)}'
          .toPersianDigit();
    }
    
    // سال قبل
    return '${jalali.day} ${_getMonthName(jalali.month)} ${jalali.year}'
        .toPersianDigit();
  }

  // ═══════════════════════════════════════════════════════════════
  // 📝 MESSAGE INFO - برای صفحه جزئیات پیام
  // ═══════════════════════════════════════════════════════════════

  /// نمایش کامل تاریخ و زمان برای Message Info
  /// مثال: "پنج‌شنبه، ۵ آذر ۱۴۰۳ ساعت ۱۴:۳۰:۴۵"
  String toDetailedLabel() {
    final jalali = toJalali();
    final h = hour.toString().padLeft(2, '0');
    final m = minute.toString().padLeft(2, '0');
    final s = second.toString().padLeft(2, '0');
    
    return '${_getPersianWeekDay()}، ${jalali.day} ${_getMonthName(jalali.month)} ${jalali.year} ساعت $h:$m:$s'
        .toPersianDigit();
  }

  // ═══════════════════════════════════════════════════════════════
  // 🔧 HELPER METHODS
  // ═══════════════════════════════════════════════════════════════

  /// دریافت نام روز هفته به فارسی
  String _getPersianWeekDay() {
    const weekDays = [
      'دوشنبه',
      'سه‌شنبه',
      'چهارشنبه',
      'پنج‌شنبه',
      'جمعه',
      'شنبه',
      'یکشنبه',
    ];
    
    // DateTime.weekday: 1 = Monday, 7 = Sunday
    return weekDays[weekday - 1];
  }

  /// دریافت نام ماه شمسی
  String _getMonthName(int month) {
    const months = [
      'فروردین',
      'اردیبهشت',
      'خرداد',
      'تیر',
      'مرداد',
      'شهریور',
      'مهر',
      'آبان',
      'آذر',
      'دی',
      'بهمن',
      'اسفند',
    ];
    
    return months[month - 1];
  }

  /// بررسی آیا دو تاریخ در یک روز هستند
  bool isSameDay(DateTime other) {
    return year == other.year && month == other.month && day == other.day;
  }

  /// بررسی آیا تاریخ امروز است
  bool get isToday {
    final now = DateTime.now();
    return isSameDay(now);
  }

  /// بررسی آیا تاریخ دیروز است
  bool get isYesterday {
    final yesterday = DateTime.now().subtract(const Duration(days: 1));
    return isSameDay(yesterday);
  }

  /// بررسی آیا تاریخ در هفته جاری است
  bool get isThisWeek {
    final now = DateTime.now();
    final difference = now.difference(this).inDays;
    return difference >= 0 && difference < 7;
  }

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RELATIVE TIME - برای پست‌ها
  // ═══════════════════════════════════════════════════════════════

  /// نمایش زمان نسبی برای پست‌ها (مثل توییتر/اینستاگرام)
  /// مثال: "۵ دقیقه پیش"، "۲ ساعت پیش"، "۳ روز پیش"
  String toRelativeTime() {
    final now = DateTime.now();
    final difference = now.difference(this);

    // کمتر از یک دقیقه
    if (difference.inSeconds < 60) {
      return 'الان';
    }

    // کمتر از یک ساعت
    if (difference.inMinutes < 60) {
      final minutes = difference.inMinutes;
      return '$minutes دقیقه پیش'.toPersianDigit();
    }

    // کمتر از یک روز
    if (difference.inHours < 24) {
      final hours = difference.inHours;
      return '$hours ساعت پیش'.toPersianDigit();
    }

    // کمتر از یک هفته
    if (difference.inDays < 7) {
      final days = difference.inDays;
      return '$days روز پیش'.toPersianDigit();
    }

    // کمتر از یک ماه
    if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return '$weeks هفته پیش'.toPersianDigit();
    }

    // بیشتر از یک ماه - نمایش تاریخ
    final jalali = toJalali();
    if (jalali.year == Jalali.now().year) {
      return '${jalali.day} ${_getMonthName(jalali.month)}'.toPersianDigit();
    }
    
    return '${jalali.day} ${_getMonthName(jalali.month)} ${jalali.year}'
        .toPersianDigit();
  }

  /// نمایش کوتاه زمان نسبی (برای UI فشرده)
  /// مثال: "۵م"، "۲س"، "۳ر"، "۲ه"
  String toShortRelativeTime() {
    final now = DateTime.now();
    final difference = now.difference(this);

    if (difference.inSeconds < 60) {
      return 'الان';
    }

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}م'.toPersianDigit();
    }

    if (difference.inHours < 24) {
      return '${difference.inHours}س'.toPersianDigit();
    }

    if (difference.inDays < 7) {
      return '${difference.inDays}ر'.toPersianDigit();
    }

    if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return '${weeks}ه'.toPersianDigit();
    }

    final jalali = toJalali();
    return '${jalali.day}/${jalali.month}'.toPersianDigit();
  }
}

// ═══════════════════════════════════════════════════════════════
// 🎯 UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/// بررسی نیاز به نمایش Date Divider بین دو پیام
bool shouldShowDateDivider(DateTime current, DateTime? previous) {
  if (previous == null) return true;
  return !current.isSameDay(previous);
}

/// گروه‌بندی پیام‌ها بر اساس تاریخ
Map<String, List<T>> groupMessagesByDate<T>(
  List<T> items,
  DateTime Function(T) getDate,
) {
  final Map<String, List<T>> grouped = {};
  
  for (final item in items) {
    final date = getDate(item);
    final key = date.toDateDividerLabel();
    grouped.putIfAbsent(key, () => []).add(item);
  }
  
  return grouped;
}

/// مرتب‌سازی گروه‌های تاریخ
List<MapEntry<String, List<T>>> sortDateGroups<T>(
  Map<String, List<T>> groups,
  DateTime Function(T) getDate,
) {
  final entries = groups.entries.toList();
  entries.sort((a, b) {
    final dateA = getDate(a.value.first);
    final dateB = getDate(b.value.first);
    return dateB.compareTo(dateA); // جدیدترین اول
  });
  return entries;
}

