// lib/features/chat/widgets/floating_date_header.dart
//
// تاریخ شناور - با الهام از تلگرام
//
// ویژگی‌ها:
// ✅ نمایش تاریخ هنگام اسکرول
// ✅ محو شدن با انیمیشن بعد از توقف اسکرول
// ✅ استایل زیبا و شیشه‌ای
// ✅ هماهنگ با تم
//

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../theme/chat_theme.dart';

/// ویجت تاریخ شناور
class FloatingDateHeader extends StatefulWidget {
  final DateTime? currentDate;
  final bool isScrolling;
  final Widget child;

  const FloatingDateHeader({
    super.key,
    this.currentDate,
    required this.isScrolling,
    required this.child,
  });

  @override
  State<FloatingDateHeader> createState() => _FloatingDateHeaderState();
}

class _FloatingDateHeaderState extends State<FloatingDateHeader>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  Timer? _hideTimer;
  bool _isVisible = false;
  DateTime? _displayedDate;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
  }

  void _setupAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));
  }

  @override
  void didUpdateWidget(FloatingDateHeader oldWidget) {
    super.didUpdateWidget(oldWidget);

    // تاریخ جدید
    if (widget.currentDate != null && widget.currentDate != _displayedDate) {
      _displayedDate = widget.currentDate;
    }

    // شروع اسکرول - نمایش
    if (widget.isScrolling && !oldWidget.isScrolling) {
      _showDate();
    }

    // توقف اسکرول - شروع تایمر برای مخفی کردن
    if (!widget.isScrolling && oldWidget.isScrolling) {
      _startHideTimer();
    }

    // اگه در حال اسکرول هستیم، تایمر رو ریست کن
    if (widget.isScrolling) {
      _hideTimer?.cancel();
    }
  }

  void _showDate() {
    if (!_isVisible) {
      setState(() => _isVisible = true);
      _animationController.forward();
    }
    _hideTimer?.cancel();
  }

  void _startHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 2), () {
      if (mounted && !widget.isScrolling) {
        _hideDate();
      }
    });
  }

  void _hideDate() {
    _animationController.reverse().then((_) {
      if (mounted) {
        setState(() => _isVisible = false);
      }
    });
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // محتوای اصلی
        widget.child,

        // تاریخ شناور
        if (_displayedDate != null)
          Positioned(
            top: 8,
            left: 0,
            right: 0,
            child: Center(
              child: AnimatedBuilder(
                animation: _animationController,
                builder: (context, child) {
                  if (!_isVisible && _animationController.isDismissed) {
                    return const SizedBox.shrink();
                  }
                  return FadeTransition(
                    opacity: _fadeAnimation,
                    child: ScaleTransition(
                      scale: _scaleAnimation,
                      child: child,
                    ),
                  );
                },
                child: _FloatingDateChip(date: _displayedDate!),
              ),
            ),
          ),
      ],
    );
  }
}

/// چیپ تاریخ شیشه‌ای
class _FloatingDateChip extends StatelessWidget {
  final DateTime date;

  const _FloatingDateChip({required this.date});

  @override
  Widget build(BuildContext context) {
    final theme = context.chatTheme;
    final dateText = _formatDate(date);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: theme.isDark
            ? Colors.black.withOpacity(0.6)
            : Colors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: theme.isDark
              ? Colors.white.withOpacity(0.1)
              : Colors.black.withOpacity(0.05),
          width: 1,
        ),
      ),
      child: Text(
        dateText,
        style: TextStyle(
          color: theme.textColor,
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final dateOnly = DateTime(date.year, date.month, date.day);

    // تاریخ شمسی
    final jalali = Jalali.fromDateTime(date);

    if (dateOnly == today) {
      return 'امروز';
    } else if (dateOnly == yesterday) {
      return 'دیروز';
    } else if (now.difference(date).inDays < 7) {
      // روز هفته
      return _getPersianWeekday(date.weekday);
    } else if (date.year == now.year) {
      // همین سال - فقط روز و ماه
      return '${jalali.day} ${_getPersianMonth(jalali.month)}';
    } else {
      // سال متفاوت
      return '${jalali.day} ${_getPersianMonth(jalali.month)} ${jalali.year}';
    }
  }

  String _getPersianWeekday(int weekday) {
    const weekdays = [
      'دوشنبه',
      'سه‌شنبه',
      'چهارشنبه',
      'پنج‌شنبه',
      'جمعه',
      'شنبه',
      'یکشنبه',
    ];
    return weekdays[weekday - 1];
  }

  String _getPersianMonth(int month) {
    const months = [
      'فروردین',
      'اردیبهشت',
      'خرداد',
      'تیر',
      'مرداد',
      'شهریور',
      'مهر',
      'آبان',
      'آذر',
      'دی',
      'بهمن',
      'اسفند',
    ];
    return months[month - 1];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 🎯 SCROLL POSITION NOTIFIER
// ═══════════════════════════════════════════════════════════════════════════

/// Controller برای مدیریت تاریخ شناور
class FloatingDateController extends ChangeNotifier {
  DateTime? _currentDate;
  bool _isScrolling = false;

  DateTime? get currentDate => _currentDate;
  bool get isScrolling => _isScrolling;

  void updateDate(DateTime date) {
    if (_currentDate != date) {
      _currentDate = date;
      notifyListeners();
    }
  }

  void setScrolling(bool scrolling) {
    if (_isScrolling != scrolling) {
      _isScrolling = scrolling;
      notifyListeners();
    }
  }
}

/// Wrapper برای استفاده راحت‌تر
class FloatingDateScrollWrapper extends StatefulWidget {
  final ScrollController scrollController;
  final List<DateTime> messageDates;
  final Widget child;

  const FloatingDateScrollWrapper({
    super.key,
    required this.scrollController,
    required this.messageDates,
    required this.child,
  });

  @override
  State<FloatingDateScrollWrapper> createState() =>
      _FloatingDateScrollWrapperState();
}

class _FloatingDateScrollWrapperState extends State<FloatingDateScrollWrapper> {
  bool _isScrolling = false;
  DateTime? _currentVisibleDate;
  Timer? _scrollEndTimer;

  @override
  void initState() {
    super.initState();
    widget.scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    widget.scrollController.removeListener(_onScroll);
    _scrollEndTimer?.cancel();
    super.dispose();
  }

  void _onScroll() {
    // شروع اسکرول
    if (!_isScrolling) {
      setState(() => _isScrolling = true);
    }

    // آپدیت تاریخ بر اساس موقعیت اسکرول
    _updateCurrentDate();

    // ریست تایمر پایان اسکرول
    _scrollEndTimer?.cancel();
    _scrollEndTimer = Timer(const Duration(milliseconds: 150), () {
      if (mounted) {
        setState(() => _isScrolling = false);
      }
    });
  }

  void _updateCurrentDate() {
    if (widget.messageDates.isEmpty) return;

    // تخمین ایندکس پیام قابل مشاهده
    final scrollOffset = widget.scrollController.offset;
    final itemHeight = 60.0; // تقریبی
    final visibleIndex = (scrollOffset / itemHeight).floor();

    if (visibleIndex >= 0 && visibleIndex < widget.messageDates.length) {
      final newDate = widget.messageDates[visibleIndex];
      if (_currentVisibleDate != newDate) {
        setState(() => _currentVisibleDate = newDate);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return FloatingDateHeader(
      currentDate: _currentVisibleDate,
      isScrolling: _isScrolling,
      child: widget.child,
    );
  }
}

