// lib/features/chat/widgets/date_divider.dart
//
// جداکننده تاریخ بین پیام‌ها
//

import 'package:flutter/material.dart';
import '../theme/chat_theme.dart';

class DateDivider extends StatelessWidget {
  final DateTime date;
  
  const DateDivider({
    super.key,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.chatTheme;
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: theme.isDark
                ? Colors.black.withOpacity(0.3)
                : Colors.black.withOpacity(0.06),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            _formatDate(date),
            style: TextStyle(
              color: theme.secondaryTextColor,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final dateOnly = DateTime(date.year, date.month, date.day);

    if (dateOnly == today) {
      return 'امروز';
    } else if (dateOnly == yesterday) {
      return 'دیروز';
    } else if (now.difference(date).inDays < 7) {
      return _getPersianWeekday(date.weekday);
    } else if (date.year == now.year) {
      return '${date.day} ${_getPersianMonth(date.month)}';
    } else {
      return '${date.day} ${_getPersianMonth(date.month)} ${date.year}';
    }
  }

  String _getPersianWeekday(int weekday) {
    const weekdays = [
      'دوشنبه',
      'سه‌شنبه',
      'چهارشنبه',
      'پنج‌شنبه',
      'جمعه',
      'شنبه',
      'یکشنبه',
    ];
    return weekdays[weekday - 1];
  }

  String _getPersianMonth(int month) {
    const months = [
      'ژانویه',
      'فوریه',
      'مارس',
      'آوریل',
      'مه',
      'ژوئن',
      'ژوئیه',
      'اوت',
      'سپتامبر',
      'اکتبر',
      'نوامبر',
      'دسامبر',
    ];
    return months[month - 1];
  }
}

/// آیا باید بین دو پیام Date Divider نشون بدیم؟
bool shouldShowDateDivider(DateTime current, DateTime? previous) {
  if (previous == null) return true;
  
  final currentDate = DateTime(current.year, current.month, current.day);
  final previousDate = DateTime(previous.year, previous.month, previous.day);
  
  return currentDate != previousDate;
}

